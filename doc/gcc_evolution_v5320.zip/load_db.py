#!/usr/bin/env python3
"""Stage-4 load: page json -> DuckDB cards table."""

from __future__ import annotations

import argparse
import json
import re
import uuid
from datetime import date
from pathlib import Path


def parse_page_from_name(path: Path) -> int:
    m = re.search(r"page_(\d+)\.json$", path.name)
    if not m:
        raise ValueError(f"invalid json page file name: {path.name}")
    return int(m.group(1)) + 1


def ensure_schema(con) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS cards (
          card_id VARCHAR PRIMARY KEY,
          source_file VARCHAR,
          page INTEGER,
          created_at DATE,
          title VARCHAR,
          summary VARCHAR,
          key_points JSON,
          tables JSON,
          entities JSON,
          tags JSON,
          raw_markdown TEXT
        )
        """
    )


def _safe_list(value):
    return value if isinstance(value, list) else []


def _safe_dict(value):
    return value if isinstance(value, dict) else {}


def _trim_summary(text: str) -> str:
    text = (text or "").strip()
    return text[:150]


def _card_uuid(source_file: Path, page: int) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{source_file.resolve()}::{page}"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Load OCR JSON cards into DuckDB")
    parser.add_argument("work_dir", type=Path, help="Directory containing page_*.json")
    parser.add_argument("source_pdf", type=Path, help="Original PDF path")
    parser.add_argument("--db", type=Path, default=Path("knowledge.duckdb"), help="DuckDB file")
    args = parser.parse_args()

    import duckdb

    if not args.work_dir.exists():
        raise FileNotFoundError(f"work dir not found: {args.work_dir}")

    json_files = sorted(args.work_dir.glob("page_*.json"), key=parse_page_from_name)

    con = duckdb.connect(str(args.db))
    ensure_schema(con)

    inserted = 0
    for jf in json_files:
        raw = jf.read_text(encoding="utf-8")
        data = json.loads(raw)

        page = parse_page_from_name(jf)
        md_path = jf.with_suffix(".md")
        raw_md = md_path.read_text(encoding="utf-8", errors="ignore") if md_path.exists() else ""

        title = str(data.get("title", "")).strip()
        summary = _trim_summary(str(data.get("summary", "")))
        key_points = _safe_list(data.get("key_points", []))
        tables = _safe_list(data.get("tables", []))
        entities = _safe_dict(data.get("entities", {}))
        tags = _safe_list(data.get("tags", []))

        card_id = _card_uuid(args.source_pdf, page)

        con.execute(
            """
            INSERT OR REPLACE INTO cards
            (card_id, source_file, page, created_at, title, summary, key_points, tables, entities, tags, raw_markdown)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                card_id,
                str(args.source_pdf),
                page,
                date.today().isoformat(),
                title,
                summary,
                json.dumps(key_points, ensure_ascii=False),
                json.dumps(tables, ensure_ascii=False),
                json.dumps(entities, ensure_ascii=False),
                json.dumps(tags, ensure_ascii=False),
                raw_md,
            ],
        )
        inserted += 1

    con.close()
    print(f"Imported {inserted} cards into {args.db}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
