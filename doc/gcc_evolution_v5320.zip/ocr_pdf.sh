#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: ./ocr_pdf.sh <input.pdf> [output_dir]"
  exit 1
fi

INPUT_PDF="$1"
OUT_DIR="${2:-./output_md}"
TMP_DIR="$OUT_DIR/.tmp_pages"
ERROR_LOG="$OUT_DIR/error.log"
OCR_ARGS="${OCR_ARGS:-}"

if [ ! -f "$INPUT_PDF" ]; then
  echo "Input PDF not found: $INPUT_PDF"
  exit 1
fi

mkdir -p "$OUT_DIR" "$TMP_DIR"
: > "$ERROR_LOG"

python -c "from pdf2image import convert_from_path, pdfinfo_from_path; from pathlib import Path; import sys; pdf=Path(sys.argv[1]); out=Path(sys.argv[2]); info=pdfinfo_from_path(str(pdf)); total=int(info.get('Pages', 0));
for i in range(total):
    pages = convert_from_path(str(pdf), dpi=300, first_page=i+1, last_page=i+1)
    if pages:
        pages[0].save(out / f'page_{i}.png', 'PNG')" "$INPUT_PDF" "$TMP_DIR"

for img in "$TMP_DIR"/page_*.png; do
  if [ ! -f "$img" ]; then
    continue
  fi

  base=$(basename "$img" .png)
  md_path="$OUT_DIR/$base.md"
  json_path="$OUT_DIR/$base.json"

  if ! python ocr.py "$img" "$md_path" --timeout 120 $OCR_ARGS; then
    echo "$(date -u +%FT%TZ) OCR_FAILED $img" >> "$ERROR_LOG"
    continue
  fi

  if [ -n "${OPENCODE_JSON_CMD:-}" ]; then
    cmd=${OPENCODE_JSON_CMD//\{md\}/$md_path}
    cmd=${cmd//\{json\}/$json_path}
    if ! eval "$cmd"; then
      echo "$(date -u +%FT%TZ) JSON_GEN_FAILED $md_path" >> "$ERROR_LOG"
      continue
    fi

    if ! python -c "import json,sys; json.load(open(sys.argv[1], encoding='utf-8'))" "$json_path"; then
      echo "$(date -u +%FT%TZ) JSON_INVALID $json_path" >> "$ERROR_LOG"
      continue
    fi
  fi
done

rm -f "$TMP_DIR"/page_*.png
rmdir "$TMP_DIR" 2>/dev/null || true

python load_db.py "$OUT_DIR" "$INPUT_PDF"

echo "Done: $INPUT_PDF -> $OUT_DIR -> knowledge.duckdb"
if [ -s "$ERROR_LOG" ]; then
  echo "Some pages failed. See: $ERROR_LOG"
fi
