"""
Multi-Arm Bandit Scheduler

# TODO: PAYMENT_REQUIRED — 完整商业实现
# 当前状态: 重定向到 knn_evolution.BanditScheduler 骨架 (ε-greedy)
# 商业版需要: Thompson Sampling (Beta 分布) + 上下文 Bandit + 多臂选择策略
"""
from .knn_evolution import BanditScheduler

# 向后兼容别名
MultiArmBandit = BanditScheduler


def thompson_sampling(*args, **kwargs):
    """# TODO: PAYMENT_REQUIRED — Beta分布 Thompson Sampling"""
    from . import upgrade_prompt
    upgrade_prompt("thompson_sampling", tier="Pro",
                   fallback="Using ε-greedy BanditScheduler instead")
    return []


def context_bandit(*args, **kwargs):
    """# TODO: PAYMENT_REQUIRED — 上下文 Bandit"""
    from . import upgrade_prompt
    upgrade_prompt("context_bandit", tier="Pro",
                   fallback="Using stateless BanditScheduler instead")
    return []


__all__ = ["BanditScheduler", "MultiArmBandit", "thompson_sampling", "context_bandit"]
