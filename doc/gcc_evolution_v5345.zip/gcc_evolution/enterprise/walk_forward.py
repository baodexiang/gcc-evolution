"""
Walk-Forward Analysis

# TODO: PAYMENT_REQUIRED — 完整商业实现
# 当前状态: 重定向到 knn_evolution.WalkForwardAnalyzer 骨架
# 商业版需要: 真实滚动窗口回测 + OOS 统计检验 + 历史数据 API 接入
"""
from .knn_evolution import WalkForwardAnalyzer


def walk_forward_backtest(*args, **kwargs):
    """# TODO: PAYMENT_REQUIRED"""
    from . import upgrade_prompt
    upgrade_prompt("walk_forward_backtest", tier="Pro",
                   fallback="Using simplified WalkForwardAnalyzer instead")
    return {}


def out_of_sample_metrics(*args, **kwargs):
    """# TODO: PAYMENT_REQUIRED"""
    from . import upgrade_prompt
    upgrade_prompt("out_of_sample_metrics", tier="Pro",
                   fallback="No OOS metrics in skeleton mode")
    return {}


__all__ = ["WalkForwardAnalyzer", "walk_forward_backtest", "out_of_sample_metrics"]
