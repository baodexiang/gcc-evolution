"""
GCC v5.350 — FreeEvolutionLoop

免费5层自进化循环：串联 L1(记忆) + L2(检索) + L3(蒸馏)
6步流程: observe → analyze → hypothesize → test → improve → integrate

设计原则：
  - 纯免费层，不依赖任何 paid/ 模块
  - 每步结果传递给下一步（链式数据流）
  - human_anchor_required=True 时，each iteration 后等待人工确认
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class IterationResult:
    """单次迭代结果"""
    iteration: int
    phase: str                    # observe/analyze/hypothesize/test/improve/integrate
    status: str = "ok"            # ok / skipped / error
    observations: list[str] = field(default_factory=list)
    hypotheses: list[str] = field(default_factory=list)
    improvements: list[str] = field(default_factory=list)
    retrieved_cards: list[dict] = field(default_factory=list)
    distilled: dict = field(default_factory=dict)
    elapsed_ms: float = 0.0
    error: str = ""
    timestamp: str = field(default_factory=_now)


class FreeEvolutionLoop:
    """
    免费5层自进化循环。

    6步流程（每次 run_iteration() 执行一轮）：
      1. observe    — 读取最近经验（L1 Memory）
      2. analyze    — 检索相关知识卡（L2 Retrieval + CardBridge）
      3. hypothesize — 从观察+检索中推导改进假设
      4. test       — 在当前配置下验证假设（沙箱执行）
      5. improve    — 生成具体改进建议
      6. integrate  — 蒸馏结果写回经验库（L3 Distillation）

    使用：
        loop = FreeEvolutionLoop(session_cfg)
        result = loop.run_iteration()
        print(result.improvements)
    """

    def __init__(self, session_config=None, max_iterations: int = 0):
        self.session_config = session_config
        self.max_iterations = max_iterations
        self._iteration = 0
        self._history: list[IterationResult] = []

        # 懒加载各层（避免 import 失败导致初始化报错）
        self._memory = None
        self._retriever = None
        self._distiller = None
        self._card_bridge = None

    # ── 各层懒加载 ────────────────────────────────────────

    def _get_memory(self):
        if self._memory is None:
            try:
                from gcc_evolution.experience_store import GlobalMemory
                self._memory = GlobalMemory()
            except Exception as e:
                logger.warning(f"[FreeLoop] L1 Memory unavailable: {e}")
        return self._memory

    def _get_retriever(self):
        if self._retriever is None:
            try:
                from gcc_evolution.L2_retrieval.retriever import HybridRetriever
                self._retriever = HybridRetriever()
            except Exception as e:
                logger.warning(f"[FreeLoop] L2 Retriever unavailable: {e}")
        return self._retriever

    def _get_card_bridge(self):
        if self._card_bridge is None:
            try:
                from gcc_evolution.card_bridge import CardBridge
                self._card_bridge = CardBridge()
                self._card_bridge.load_index()
            except Exception as e:
                logger.warning(f"[FreeLoop] CardBridge unavailable: {e}")
        return self._card_bridge

    def _get_distiller(self):
        if self._distiller is None:
            try:
                from gcc_evolution.distiller import Distiller
                self._distiller = Distiller()
            except Exception as e:
                logger.warning(f"[FreeLoop] L3 Distiller unavailable: {e}")
        return self._distiller

    # ── 6步流程 ───────────────────────────────────────────

    def _step_observe(self) -> list[str]:
        """Step 1: 读取最近经验（L1 Memory）"""
        observations = []
        memory = self._get_memory()
        if memory:
            try:
                recent = memory.get_recent(limit=10)
                for exp in recent:
                    obs = exp.get("summary") or exp.get("content", "")[:80]
                    if obs:
                        observations.append(obs)
            except Exception as e:
                logger.debug(f"[FreeLoop][observe] {e}")
        if not observations:
            observations = ["(no recent experiences — cold start)"]
        return observations

    def _step_analyze(self, observations: list[str]) -> list[dict]:
        """Step 2: 检索相关知识卡（L2 + CardBridge）"""
        cards = []
        # 从观察提取关键词
        keywords = []
        for obs in observations[:3]:
            words = [w for w in obs.split() if len(w) > 3][:3]
            keywords.extend(words)

        cb = self._get_card_bridge()
        if cb and keywords:
            try:
                results = cb.query(keywords=keywords[:5], min_confidence=0.3)
                cards = results[:5]
            except Exception as e:
                logger.debug(f"[FreeLoop][analyze] CardBridge: {e}")

        # fallback: L2 HybridRetriever
        if not cards:
            retriever = self._get_retriever()
            if retriever:
                try:
                    query = " ".join(observations[:2])
                    raw = retriever.retrieve(query, top_k=5)
                    for r in raw:
                        cards.append({"card_id": r.get("id", ""), "title": r.get("title", ""),
                                      "rules": [], "confidence": r.get("score", 0.5)})
                except Exception as e:
                    logger.debug(f"[FreeLoop][analyze] Retriever: {e}")
        return cards

    def _step_hypothesize(self, observations: list[str], cards: list[dict]) -> list[str]:
        """Step 3: 从观察+检索推导改进假设"""
        hypotheses = []

        # 基于知识卡规则生成假设
        for card in cards[:3]:
            rules = card.get("rules", [])
            for rule in rules[:1]:
                condition = rule.get("if", "")
                action = rule.get("then", "")
                if condition and action:
                    hypotheses.append(f"若 {condition[:40]}，则 {action[:40]}")

        # 基于观察生成通用假设
        if observations and observations[0] != "(no recent experiences — cold start)":
            hypotheses.append(f"改善方向: {observations[0][:60]}")

        if not hypotheses:
            hypotheses = ["(no hypothesis — need more experience data)"]
        return hypotheses

    def _step_test(self, hypotheses: list[str]) -> dict:
        """Step 4: 验证假设（免费层：规则检查，无真实回测）"""
        results = {}
        for i, hyp in enumerate(hypotheses):
            # 免费层只做格式/逻辑一致性检查
            valid = len(hyp) > 5 and hyp != "(no hypothesis — need more experience data)"
            results[f"h{i}"] = {"hypothesis": hyp[:60], "valid": valid, "method": "rule_check"}
        return results

    def _step_improve(self, test_results: dict, hypotheses: list[str]) -> list[str]:
        """Step 5: 生成具体改进建议"""
        improvements = []
        for key, r in test_results.items():
            if r.get("valid"):
                improvements.append(f"[建议] {r['hypothesis']}")
        if not improvements:
            improvements = ["(当前轮无有效改进建议，继续收集经验)"]
        return improvements

    def _step_integrate(self, result: IterationResult) -> dict:
        """Step 6: 蒸馏结果写回经验库（L3 Distillation）"""
        distilled = {
            "iteration": result.iteration,
            "improvements_count": len(result.improvements),
            "integrated_at": _now(),
        }

        distiller = self._get_distiller()
        if distiller and result.improvements:
            try:
                summary = "; ".join(result.improvements[:3])
                distiller.distill({"summary": summary, "source": "free_loop",
                                   "iteration": result.iteration})
                distilled["written_to_distiller"] = True
            except Exception as e:
                logger.debug(f"[FreeLoop][integrate] Distiller: {e}")
                distilled["written_to_distiller"] = False

        return distilled

    # ── 主入口 ────────────────────────────────────────────

    def run_iteration(self) -> IterationResult:
        """执行一轮完整的6步进化循环。"""
        import time
        t0 = time.time()

        self._iteration += 1
        result = IterationResult(iteration=self._iteration, phase="running")

        # 检查最大迭代数
        if self.max_iterations > 0 and self._iteration > self.max_iterations:
            result.phase = "stopped"
            result.status = "skipped"
            result.error = f"max_iterations={self.max_iterations} reached"
            return result

        try:
            # 1. Observe
            result.phase = "observe"
            result.observations = self._step_observe()

            # 2. Analyze
            result.phase = "analyze"
            result.retrieved_cards = self._step_analyze(result.observations)

            # 3. Hypothesize
            result.phase = "hypothesize"
            result.hypotheses = self._step_hypothesize(result.observations, result.retrieved_cards)

            # 4. Test
            result.phase = "test"
            test_results = self._step_test(result.hypotheses)

            # 5. Improve
            result.phase = "improve"
            result.improvements = self._step_improve(test_results, result.hypotheses)

            # 6. Integrate
            result.phase = "integrate"
            result.distilled = self._step_integrate(result)

            result.phase = "done"
            result.status = "ok"

        except Exception as e:
            result.status = "error"
            result.error = str(e)
            logger.error(f"[FreeLoop] iteration {self._iteration} error: {e}")

        result.elapsed_ms = round((time.time() - t0) * 1000, 1)
        self._history.append(result)
        return result

    def run(self, n: int = 1) -> list[IterationResult]:
        """运行 n 轮迭代，返回所有结果。"""
        return [self.run_iteration() for _ in range(n)]

    @property
    def iteration_count(self) -> int:
        return self._iteration

    @property
    def history(self) -> list[IterationResult]:
        return list(self._history)
