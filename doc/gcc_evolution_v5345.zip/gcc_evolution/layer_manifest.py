"""Canonical v5.350 8-layer tier manifest for gcc-evo.

二元 free/paid 架构：
  free=True  → UI / L0 / L1 / L2 / L3（免费5层基础）
  free=False → L4 / L5 / DA（付费进化层）

商业增强包统一位于 paid/l4/enhancement/，不再有 paid/l0~l3 子目录。
"""
from __future__ import annotations

LAYER_TIER_MATRIX = {
    'UI': {
        'name': 'Setup Dashboard',
        'free': True,
        'paid': False,
        'path': 'gcc_evolution/free/ui',
        'note': 'Configuration, connector setup, state monitoring, access visibility.',
    },
    'L0': {
        'name': 'Foundation Governance Layer',
        'free': True,
        'paid': False,
        'path': 'gcc_evolution/free/l0',
        'note': 'Gate check, direction anchor validation, session bootstrap.',
    },
    'L1': {
        'name': 'Memory',
        'free': True,
        'paid': False,
        'path': 'gcc_evolution/free/l1',
        'note': 'Experience storage, memory tiers, recall.',
    },
    'L2': {
        'name': 'Retrieval',
        'free': True,
        'paid': False,
        'path': 'gcc_evolution/free/l2',
        'note': 'RAG pipeline, hybrid retrieval, card bridge injection.',
    },
    'L3': {
        'name': 'Distillation',
        'free': True,
        'paid': False,
        'path': 'gcc_evolution/free/l3',
        'note': 'Experience distillation, pattern extraction.',
    },
    'L4': {
        'name': 'Decision Evolution Engine',
        'free': False,
        'paid': True,
        'path': 'gcc_evolution/paid/l4',
        'note': 'KNN evolution, walk-forward, bandit scheduler, commercial enhancements.',
    },
    'L5': {
        'name': 'Orchestration',
        'free': False,
        'paid': True,
        'path': 'gcc_evolution/paid/l5',
        'note': 'Overnight run orchestration, watchdog gate.',
    },
    'DA': {
        'name': 'Direction Anchor',
        'free': False,
        'paid': True,
        'path': 'gcc_evolution/paid/da',
        'note': 'Constitutional gate, forbidden file guard.',
    },
}


def canonical_layers() -> list[str]:
    return ['UI', 'L0', 'L1', 'L2', 'L3', 'L4', 'L5', 'DA']


def free_layers() -> list[str]:
    return [k for k, v in LAYER_TIER_MATRIX.items() if v['free']]


def paid_layers() -> list[str]:
    return [k for k, v in LAYER_TIER_MATRIX.items() if v['paid']]
