# Paid Surface

`gcc_evolution/paid/` is the canonical paid boundary.

## Paid Core Units

- `l4` decision evolution engine + commercial enhancements (`l4/enhancement/`)
- `l5` closed-loop orchestration
- `da` direction anchor

## Pricing Tiers

| Tier | Price | Layers |
|------|-------|--------|
| Community | Free (MIT) | UI + L0~L3 (5 foundation layers) |
| Pro | $79/mo | + L4 / L5 / DA (evolution & orchestration) |
| Enterprise | $500+ | Pro + SLA / custom integration / dedicated support |

`L4`, `L5`, and `DA` are the canonical paid-core layers.
Commercial enhancements (formerly paid/l0~l3) are consolidated in `l4/enhancement/`.
