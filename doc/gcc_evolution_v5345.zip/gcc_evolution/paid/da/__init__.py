"""Paid Direction Anchor boundary.

DA 宪法门控：确保进化不修改 forbidden_files，方向不偏移。
DA-01~DA-06 六条宪法规则。
"""
from pathlib import Path

from ...direction_anchor import DirectionAnchor, PrincipleSet
from ..common import PaidBoundary

DA_BOUNDARY = PaidBoundary(
    layer='DA',
    tier='Paid',
    features=(
        'Constitutional gating from L4 to L5',
        'Human final decision enforcement',
        'Manual override guarantees',
        'forbidden_files guard (DA-01)',
    ),
    note='Canonical paid-only DA layer in v5.300.',
)


class DABlockedError(Exception):
    """DA 宪法门控触发：禁止操作被阻止。"""
    def __init__(self, rule: str, detail: str = ""):
        self.rule = rule
        self.detail = detail
        super().__init__(f"[DA-BLOCKED] {rule}: {detail}")


def check_forbidden_files(
    files_to_modify: list[str],
    forbidden_files: list[str],
) -> None:
    """
    DA-01: 检查待修改文件是否触碰 forbidden_files。
    触发时抛出 DABlockedError。

    # TODO: PAYMENT_REQUIRED — 商业版集成实时文件监控 + 审计日志
    """
    forbidden_set = {str(Path(f)) for f in forbidden_files}
    for f in files_to_modify:
        if str(Path(f)) in forbidden_set:
            raise DABlockedError(
                rule="DA-01",
                detail=f"forbidden file modification attempted: {f}",
            )


def run_overnight(
    evolution_loop,
    n_experiments: int = 100,
    forbidden_files: list[str] | None = None,
) -> list:
    """
    DA-06: 隔夜100次实验场景，每次实验前检查 forbidden_files。

    # TODO: PAYMENT_REQUIRED — 商业版需要真实 WalkForward 数据接入
    """
    forbidden = forbidden_files or []
    results = []
    for i in range(n_experiments):
        # DA-01: 检查本次实验的候选文件
        candidate_files = [evolution_loop.session_config.mutable_file] if (
            evolution_loop.session_config and
            evolution_loop.session_config.mutable_file
        ) else []
        try:
            check_forbidden_files(candidate_files, forbidden)
        except DABlockedError:
            results.append({"status": "da_blocked", "run": i + 1})
            continue
        result = evolution_loop.run_one()
        results.append(result.to_dict() if hasattr(result, 'to_dict') else {"status": result.status})
    return results


__all__ = [
    'DA_BOUNDARY', 'DirectionAnchor', 'PrincipleSet',
    'DABlockedError', 'check_forbidden_files', 'run_overnight',
]
