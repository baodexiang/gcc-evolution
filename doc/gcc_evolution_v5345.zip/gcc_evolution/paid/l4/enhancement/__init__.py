"""
paid/l4/enhancement — 商业增强包（原 paid/l0~l3 内容统一迁移至此）

包含：
  phase2_quality        L0 阶段2质量门控
  phase3_math           L0 阶段3数学评估
  phase4_truth_table    L0 阶段4决策真值表（P003 接受评分）
  advanced_memory       L1 高级记忆模块
  advanced_retrieval    L2 高级检索模块
  advanced_distillation L3 高级蒸馏模块
"""
