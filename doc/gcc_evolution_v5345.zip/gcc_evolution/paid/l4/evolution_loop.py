"""
GCC v5.350 — EvolutionLoop (Paid L4)

付费进化循环主体：KNN + WalkForward + OverfitDetector + BanditScheduler

# TODO: PAYMENT_REQUIRED
# 本模块包含骨架实现，完整商业版本需要：
#   1. 真实 KNNEvolver 集成（需 sklearn/faiss，见 enterprise/knn_evolution.py）
#   2. 真实 WalkForwardAnalyzer 回测引擎（需历史数据 API 接入）
#   3. BanditScheduler Thompson Sampling 实际参数优化
#   4. License key 验证（PaidBoundary 升级为实际授权检查）
# 当前: 骨架可运行，核心算法为简化占位
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from ..common import PaidBoundary

logger = logging.getLogger(__name__)

_PAID_GATE = PaidBoundary(
    "L4",
    "Pro",
    ("evolution_loop", "knn_optimization", "walk_forward", "bandit_schedule"),
    "EvolutionLoop requires Pro tier.",
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── 内部组件（简化实现，商业版替换为真实算法）────────────────

class _KNNEvolver:
    """
    KNN 进化器（简化版）。
    # TODO: PAYMENT_REQUIRED — 替换为 enterprise/knn_evolution.py 真实实现
    真实版需要: sklearn NearestNeighbors + 特征向量化 + 距离度量优化
    """
    def __init__(self, k: int = 5):
        self.k = k
        self._history: list[dict] = []

    def fit(self, experiences: list[dict]) -> None:
        self._history = experiences[-50:]  # 简化：只保留最近50条

    def suggest(self, context: dict) -> dict:
        """基于相似历史经验推荐参数变更。"""
        if not self._history:
            return {"suggestion": "no_history", "confidence": 0.0}
        # 简化：按 success 字段选最优经验
        best = max(self._history, key=lambda x: x.get("score", 0.0), default={})
        return {
            "suggestion": best.get("param_change", "{}"),
            "confidence": min(len(self._history) / 10.0, 0.9),
            "source_experience": best.get("id", ""),
        }


class _WalkForwardAnalyzer:
    """
    Walk-Forward 分析器（简化版）。
    # TODO: PAYMENT_REQUIRED — 替换为 enterprise/walk_forward.py 真实实现
    真实版需要: 历史数据分段回测 + 滚动窗口参数更新 + OOS 验证
    """
    def __init__(self, train_window: int = 30, test_window: int = 7):
        self.train_window = train_window
        self.test_window = test_window

    def evaluate(self, candidate: dict, baseline_score: float) -> dict:
        """简化评估：基于候选参数置信度估算 OOS 得分。"""
        confidence = candidate.get("confidence", 0.5)
        oos_score = baseline_score * (0.8 + confidence * 0.3)  # 简化公式
        return {
            "oos_score": round(oos_score, 4),
            "train_window": self.train_window,
            "test_window": self.test_window,
            "method": "simplified",  # 商业版改为 "walk_forward"
        }


class _OverfitDetector:
    """过拟合检测器（阈值法）。"""
    def __init__(self, max_gap: float = 0.15):
        self.max_gap = max_gap  # IS/OOS 最大允许差距

    def is_overfit(self, in_sample_score: float, oos_score: float) -> bool:
        gap = in_sample_score - oos_score
        return gap > self.max_gap


class _BanditScheduler:
    """
    Bandit 调度器（ε-greedy 简化版）。
    # TODO: PAYMENT_REQUIRED — 替换为 enterprise/bandit_scheduler.py Thompson Sampling
    真实版需要: Beta 分布参数估计 + 上下文 Bandit + 多臂选择策略
    """
    def __init__(self, epsilon: float = 0.2):
        self.epsilon = epsilon
        self._arms: dict[str, dict] = {}  # {arm_id: {wins, total}}

    def select(self, arms: list[str]) -> str:
        """ε-greedy 选择。"""
        import random
        if not arms:
            return ""
        if random.random() < self.epsilon or not self._arms:
            return random.choice(arms)
        # 选胜率最高的 arm
        rates = {a: self._arms.get(a, {}).get("wins", 0) /
                    max(self._arms.get(a, {}).get("total", 1), 1)
                 for a in arms}
        return max(rates, key=rates.get)

    def update(self, arm: str, reward: float) -> None:
        if arm not in self._arms:
            self._arms[arm] = {"wins": 0, "total": 0}
        self._arms[arm]["total"] += 1
        if reward > 0:
            self._arms[arm]["wins"] += 1


# ── EvolutionLoop 主体 ────────────────────────────────────────

@dataclass
class EvolutionResult:
    """单次进化结果。"""
    run_id: str
    status: str          # keep / discard / error
    candidate: dict = field(default_factory=dict)
    oos_score: float = 0.0
    baseline_score: float = 0.0
    market_regime: str = ""
    discard_reason: str = ""
    overfit: bool = False
    elapsed_ms: float = 0.0
    timestamp: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "status": self.status,
            "candidate": self.candidate,
            "oos_score": self.oos_score,
            "baseline_score": self.baseline_score,
            "market_regime": self.market_regime,
            "discard_reason": self.discard_reason,
            "overfit": self.overfit,
            "elapsed_ms": self.elapsed_ms,
            "timestamp": self.timestamp,
        }


class EvolutionLoop:
    """
    付费进化循环 (L4 Pro)。

    run_one() 执行一次完整进化实验：
      1. Bandit 选择实验方向
      2. KNN 推荐候选参数
      3. WalkForward 评估 OOS 得分
      4. OverfitDetector 过拟合检查
      5. WatchdogGate 市场状态差异化阈值（keep/discard）
      6. 写入 truth_table（付费专属）
    """

    def __init__(self, session_config=None, baseline_score: float = 0.0,
                 market_regime: str = "TREND"):
        self.session_config = session_config
        self.baseline_score = baseline_score
        self.market_regime = market_regime
        self._run_count = 0
        self._consecutive_discards = 0

        self._knn = _KNNEvolver()
        self._wf = _WalkForwardAnalyzer()
        self._overfit = _OverfitDetector()
        self._bandit = _BanditScheduler()
        self._history: list[EvolutionResult] = []

    def load_experiences(self, experiences: list[dict]) -> None:
        """加载历史经验供 KNN 使用。"""
        self._knn.fit(experiences)

    def run_one(self) -> EvolutionResult:
        """执行一次进化实验，返回 keep/discard 结果。"""
        import time, uuid
        t0 = time.time()
        self._run_count += 1
        run_id = f"EVO-{self._run_count:04d}-{uuid.uuid4().hex[:6]}"

        result = EvolutionResult(
            run_id=run_id,
            status="error",
            baseline_score=self.baseline_score,
            market_regime=self.market_regime,
        )

        try:
            # 1. Bandit 选择实验方向
            arms = ["knn_suggest", "random_perturb", "rule_based"]
            selected_arm = self._bandit.select(arms)

            # 2. KNN 推荐候选
            context = {"market_regime": self.market_regime,
                       "baseline_score": self.baseline_score}
            candidate = self._knn.suggest(context)
            candidate["arm"] = selected_arm
            result.candidate = candidate

            # 3. WalkForward OOS 评估
            wf_result = self._wf.evaluate(candidate, self.baseline_score)
            result.oos_score = wf_result["oos_score"]

            # 4. 过拟合检测
            in_sample = self.baseline_score * 1.1  # 简化：IS稍优于baseline
            result.overfit = self._overfit.is_overfit(in_sample, result.oos_score)

            # 5. WatchdogGate 判断（市场状态差异化阈值）
            try:
                from gcc_evolution.paid.l5.watchdog_gate import WatchdogGate
                gate = WatchdogGate()
                gate_result = gate.evaluate(
                    oos_score=result.oos_score,
                    baseline_score=self.baseline_score,
                    market_regime=self.market_regime,
                    overfit=result.overfit,
                )
                result.status = gate_result["verdict"]
                result.discard_reason = gate_result.get("reason", "")
            except ImportError:
                # WatchdogGate 未就绪时，简化判断
                delta = result.oos_score - self.baseline_score
                result.status = "keep" if delta >= 0 and not result.overfit else "discard"
                result.discard_reason = "" if result.status == "keep" else (
                    "overfit" if result.overfit else f"delta={delta:.4f}<0")

            # 6. Bandit 更新
            reward = 1.0 if result.status == "keep" else 0.0
            self._bandit.update(selected_arm, reward)

            # 连续 DISCARD 计数
            if result.status == "discard":
                self._consecutive_discards += 1
                if self._consecutive_discards >= 10:
                    logger.warning(
                        f"[EvolutionLoop] {self._consecutive_discards} consecutive DISCARDs — "
                        "direction exhausted warning"
                    )
            else:
                self._consecutive_discards = 0

            # 写入 truth_table（付费专属）
            self._write_truth_table(result)

        except Exception as e:
            result.status = "error"
            result.discard_reason = str(e)
            logger.error(f"[EvolutionLoop] {run_id} error: {e}")

        result.elapsed_ms = round((time.time() - t0) * 1000, 1)
        self._history.append(result)
        return result

    def _write_truth_table(self, result: EvolutionResult) -> None:
        """写入真值表记录（付费专属，免费层不写入）。"""
        try:
            from gcc_evolution.paid.l4.enhancement.phase4_truth_table import TruthTableRecord
            rec = TruthTableRecord(
                candidate_id=result.run_id,
                pattern_score=result.candidate.get("confidence", 0.0),
                precision=0.0, recall=0.0, f1=0.0,
                composite_score=result.oos_score,
                latency_ms=result.elapsed_ms,
                latency_budget_ms=5000.0,
                accepted=(result.status == "keep"),
                market_regime=result.market_regime,
                score_before=result.baseline_score,
                param_change=str(result.candidate.get("suggestion", "")),
                discard_reason=result.discard_reason,
            )
            # 追加到 state/truth_table.jsonl
            import json
            tt_path = Path("state/truth_table.jsonl")
            tt_path.parent.mkdir(exist_ok=True)
            with open(tt_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec.to_dict(), ensure_ascii=False) + "\n")
        except Exception as e:
            logger.debug(f"[EvolutionLoop] truth_table write skipped: {e}")

    @property
    def run_count(self) -> int:
        return self._run_count

    @property
    def history(self) -> list[EvolutionResult]:
        return list(self._history)

    def consecutive_discards(self) -> int:
        return self._consecutive_discards
