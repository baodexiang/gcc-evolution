"""
GCC v5.350 — WatchdogGate (Paid L5)

过拟合 + 市场状态差异化阈值门控 (GCC-AR-04)

市场状态阈值（OOS改善率需超过此值才 keep）：
  TREND    : 2%
  RANGE    : 3%
  HIGH_VOL : 5%

# TODO: PAYMENT_REQUIRED
# 当前: 阈值逻辑完整，但以下部分需商业化后补全：
#   1. 市场状态自动识别（需接入实时行情 API）
#   2. 动态阈值校准（基于近期信号质量自适应调整）
#   3. License key 验证
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from ..common import PaidBoundary

logger = logging.getLogger(__name__)

_PAID_GATE = PaidBoundary(
    "L5",
    "Pro",
    ("watchdog_gate", "overfit_detection", "regime_threshold"),
    "WatchdogGate requires Pro tier.",
)

# 市场状态 → 最小改善率阈值
_REGIME_THRESHOLDS: dict[str, float] = {
    "TREND":    0.02,   # 趋势市：改善 ≥ 2%
    "RANGE":    0.03,   # 震荡市：改善 ≥ 3%
    "HIGH_VOL": 0.05,   # 高波动：改善 ≥ 5%
    "UNKNOWN":  0.03,   # 未知：保守取 3%
}


@dataclass
class GateResult:
    verdict: str          # keep / discard
    reason: str
    oos_score: float
    baseline_score: float
    improvement_rate: float
    threshold: float
    market_regime: str
    overfit: bool

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "reason": self.reason,
            "oos_score": self.oos_score,
            "baseline_score": self.baseline_score,
            "improvement_rate": self.improvement_rate,
            "threshold": self.threshold,
            "market_regime": self.market_regime,
            "overfit": self.overfit,
        }


class WatchdogGate:
    """
    进化看门狗：判断候选实验是否值得保留。

    evaluate() 返回 verdict: keep / discard
    """

    def __init__(self, custom_thresholds: dict[str, float] | None = None):
        self._thresholds = dict(_REGIME_THRESHOLDS)
        if custom_thresholds:
            self._thresholds.update(custom_thresholds)

    def evaluate(
        self,
        oos_score: float,
        baseline_score: float,
        market_regime: str = "UNKNOWN",
        overfit: bool = False,
    ) -> dict:
        """
        判断候选是否 keep。

        规则：
          1. 过拟合 → 直接 discard
          2. OOS 改善率 < 市场状态阈值 → discard
          3. 否则 → keep
        """
        regime = market_regime.upper() if market_regime else "UNKNOWN"
        threshold = self._thresholds.get(regime, self._thresholds["UNKNOWN"])

        improvement_rate = (
            (oos_score - baseline_score) / max(abs(baseline_score), 1e-9)
            if baseline_score != 0
            else (oos_score if oos_score > 0 else -1.0)
        )

        # 规则1：过拟合直接丢弃
        if overfit:
            result = GateResult(
                verdict="discard",
                reason=f"overfit detected (IS/OOS gap > threshold)",
                oos_score=oos_score,
                baseline_score=baseline_score,
                improvement_rate=round(improvement_rate, 4),
                threshold=threshold,
                market_regime=regime,
                overfit=True,
            )
            logger.info(f"[WatchdogGate] DISCARD overfit regime={regime}")
            return result.to_dict()

        # 规则2：改善率不足
        if improvement_rate < threshold:
            result = GateResult(
                verdict="discard",
                reason=(
                    f"improvement_rate={improvement_rate:.2%} < "
                    f"threshold={threshold:.0%} (regime={regime})"
                ),
                oos_score=oos_score,
                baseline_score=baseline_score,
                improvement_rate=round(improvement_rate, 4),
                threshold=threshold,
                market_regime=regime,
                overfit=False,
            )
            logger.info(
                f"[WatchdogGate] DISCARD rate={improvement_rate:.2%} < {threshold:.0%} regime={regime}"
            )
            return result.to_dict()

        # Keep
        result = GateResult(
            verdict="keep",
            reason=f"improvement_rate={improvement_rate:.2%} >= threshold={threshold:.0%}",
            oos_score=oos_score,
            baseline_score=baseline_score,
            improvement_rate=round(improvement_rate, 4),
            threshold=threshold,
            market_regime=regime,
            overfit=False,
        )
        logger.info(
            f"[WatchdogGate] KEEP rate={improvement_rate:.2%} >= {threshold:.0%} regime={regime}"
        )
        return result.to_dict()

    def get_threshold(self, market_regime: str) -> float:
        return self._thresholds.get(market_regime.upper(), self._thresholds["UNKNOWN"])
