"""
Paper Formula Implementation: DualPath KV-Cache
================================================
Layer : Data

Source mapping:
- Eq.(1): cache allocation ratio (hot vs cold path split)
- Eq.(2): hit-rate objective (weighted harmonic mean of hot/cold hit rates)
- Eq.(3): latency estimate (allocation-weighted path latency)
"""

from __future__ import annotations

import math

KV_EPSILON: float = 1e-8


def eq_1_allocation_ratio(
    hot_access_freq: float,
    cold_access_freq: float,
) -> float:
    """
    Eq.(1) hot-path allocation ratio.

    ratio = hot_freq / (hot_freq + cold_freq)
    Clamped to [0, 1]; returns 0.5 when both are zero.
    """
    h = max(0.0, float(hot_access_freq))
    c = max(0.0, float(cold_access_freq))
    total = h + c
    if total <= KV_EPSILON:
        return 0.5  # equal split by default
    return h / total


def eq_2_hit_rate_objective(
    hot_hit_rate: float,
    cold_hit_rate: float,
    allocation_ratio: float,
) -> float:
    """
    Eq.(2) weighted harmonic mean of hot/cold hit rates.

    H = 1 / (ratio/hot_rate + (1-ratio)/cold_rate)
    Falls back to 0.0 when either denominator component is zero.
    """
    r = max(0.0, min(1.0, float(allocation_ratio)))
    hh = max(0.0, float(hot_hit_rate))
    ch = max(0.0, float(cold_hit_rate))
    hot_term = r / hh if hh > KV_EPSILON else 0.0
    cold_term = (1.0 - r) / ch if ch > KV_EPSILON else 0.0
    denom = hot_term + cold_term
    if denom <= KV_EPSILON:
        return 0.0
    return 1.0 / denom


def eq_3_latency_estimate(
    hot_latency_ms: float,
    cold_latency_ms: float,
    allocation_ratio: float,
) -> float:
    """
    Eq.(3) allocation-weighted average latency.

    latency = ratio * hot_latency + (1 - ratio) * cold_latency
    """
    r = max(0.0, min(1.0, float(allocation_ratio)))
    hl = max(0.0, float(hot_latency_ms))
    cl = max(0.0, float(cold_latency_ms))
    return r * hl + (1.0 - r) * cl
