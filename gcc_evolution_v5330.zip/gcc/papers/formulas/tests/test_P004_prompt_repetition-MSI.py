"""Unit tests for P004 Prompt Repetition hard-rule formulas."""

import pytest

from gcc.papers.formulas.P004_prompt_repetition import (
    eq_1_repetition_performance_gain,
    eq_2_optimal_repetition_count,
)


class TestEq1RepetitionPerformanceGain:
    def test_zero_repetitions_yields_zero_gain(self):
        assert eq_1_repetition_performance_gain(repetition_count=0) == pytest.approx(0.0)

    def test_gain_approaches_max_gain(self):
        gain = eq_1_repetition_performance_gain(repetition_count=100, max_gain=1.0)
        assert gain == pytest.approx(1.0, abs=1e-4)

    def test_monotonic_increase(self):
        gains = [eq_1_repetition_performance_gain(n) for n in range(10)]
        assert all(gains[i] <= gains[i + 1] for i in range(9))

    def test_negative_count_clamped_to_zero(self):
        result = eq_1_repetition_performance_gain(repetition_count=-5)
        assert result == pytest.approx(0.0)

    def test_higher_decay_reaches_max_faster(self):
        fast = eq_1_repetition_performance_gain(repetition_count=3, decay_rate=1.0)
        slow = eq_1_repetition_performance_gain(repetition_count=3, decay_rate=0.1)
        assert fast > slow


class TestEq2OptimalRepetitionCount:
    def test_returns_integer(self):
        result = eq_2_optimal_repetition_count()
        assert isinstance(result, int)

    def test_higher_cost_lowers_optimal_count(self):
        cheap = eq_2_optimal_repetition_count(cost_per_repeat=0.01)
        expensive = eq_2_optimal_repetition_count(cost_per_repeat=0.5)
        assert cheap >= expensive

    def test_zero_max_gain_yields_zero_count(self):
        result = eq_2_optimal_repetition_count(max_gain=0.0)
        assert result == 0

    def test_result_within_max_search(self):
        result = eq_2_optimal_repetition_count(max_search=5)
        assert 0 <= result <= 5
