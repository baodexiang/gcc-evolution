"""Unit tests for P005 DualPath KV-Cache hard-rule formulas."""

import pytest

from gcc.papers.formulas.P005_dualpath_kvcache import (
    eq_1_allocation_ratio,
    eq_2_hit_rate_objective,
    eq_3_latency_estimate,
)


class TestEq1AllocationRatio:
    def test_equal_freq_yields_half(self):
        assert eq_1_allocation_ratio(1.0, 1.0) == pytest.approx(0.5)

    def test_all_hot_yields_one(self):
        assert eq_1_allocation_ratio(10.0, 0.0) == pytest.approx(1.0)

    def test_all_cold_yields_zero(self):
        assert eq_1_allocation_ratio(0.0, 10.0) == pytest.approx(0.0)

    def test_zero_both_defaults_to_half(self):
        assert eq_1_allocation_ratio(0.0, 0.0) == pytest.approx(0.5)

    def test_result_in_unit_interval(self):
        r = eq_1_allocation_ratio(3.0, 7.0)
        assert 0.0 <= r <= 1.0


class TestEq2HitRateObjective:
    def test_equal_hit_rates_returns_that_rate(self):
        # harmonic mean of equal values equals the value
        result = eq_2_hit_rate_objective(0.8, 0.8, 0.5)
        assert result == pytest.approx(0.8)

    def test_zero_hot_hit_rate_falls_back(self):
        result = eq_2_hit_rate_objective(0.0, 0.9, 0.5)
        # hot_term=0 → only cold_term contributes → 1 / (0.5/0.9) = 1.8 capped
        assert result >= 0.0

    def test_higher_hit_rates_improve_objective(self):
        low = eq_2_hit_rate_objective(0.4, 0.4, 0.5)
        high = eq_2_hit_rate_objective(0.9, 0.9, 0.5)
        assert high > low

    def test_both_zero_returns_zero(self):
        assert eq_2_hit_rate_objective(0.0, 0.0, 0.5) == pytest.approx(0.0)


class TestEq3LatencyEstimate:
    def test_all_hot_returns_hot_latency(self):
        assert eq_3_latency_estimate(2.0, 10.0, 1.0) == pytest.approx(2.0)

    def test_all_cold_returns_cold_latency(self):
        assert eq_3_latency_estimate(2.0, 10.0, 0.0) == pytest.approx(10.0)

    def test_weighted_blend(self):
        result = eq_3_latency_estimate(hot_latency_ms=4.0, cold_latency_ms=8.0, allocation_ratio=0.5)
        assert result == pytest.approx(6.0)

    def test_more_hot_lowers_latency_when_hot_faster(self):
        less_hot = eq_3_latency_estimate(2.0, 10.0, 0.3)
        more_hot = eq_3_latency_estimate(2.0, 10.0, 0.8)
        assert more_hot < less_hot
