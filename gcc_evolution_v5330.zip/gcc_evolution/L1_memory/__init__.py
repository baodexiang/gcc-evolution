"""
L1 Memory — gcc-evo Open Core
License: BUSL 1.1 | Free for personal/academic/<$1M revenue
Commercial: gcc-evo.dev/licensing

Memory tier abstraction for multi-layer knowledge storage (sensory, short-term, long-term).
"""

from .memory_tiers import SensoryMemory, ShortTermMemory, LongTermMemory
from .memory_tiers import ArchivalMemory, MemoryStack  # E7: 4-tier infinite memory
from .storage import MemoryStorage, JSONStorage, SQLiteStorage

__all__ = [
    "SensoryMemory",
    "ShortTermMemory",
    "LongTermMemory",
    "ArchivalMemory",
    "MemoryStack",
    "MemoryStorage",
    "JSONStorage",
    "SQLiteStorage",
]

__version__ = "1.0.0"
