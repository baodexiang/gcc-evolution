"""
Memory Tier Abstractions

Three-level memory architecture:
  • Sensory: Real-time signal processing (current observation)
  • Short-term: Sliding window history (recent N steps)
  • Long-term: Persistent knowledge base (historical patterns)
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, List, Dict, Optional, Tuple


class MemoryTier(ABC):
    """Abstract base for memory tier."""

    @abstractmethod
    def store(self, key: str, value: Any, metadata: Dict[str, Any] = None) -> None:
        """Store value in this memory tier."""
        pass

    @abstractmethod
    def retrieve(self, key: str) -> Optional[Any]:
        """Retrieve value from this memory tier."""
        pass

    @abstractmethod
    def list_keys(self) -> List[str]:
        """List all stored keys."""
        pass


class SensoryMemory(MemoryTier):
    """
    Real-time signal processing layer.

    Characteristics:
      • Latest observation only (no history)
      • Updated every step with current state
      • Used for immediate signal detection

    Example:
      >>> sensory = SensoryMemory()
      >>> sensory.store("price", 45230.50)
      >>> sensory.retrieve("price")
      45230.50
    """

    def __init__(self):
        self._current_state: Dict[str, Any] = {}
        self._last_update: Dict[str, datetime] = {}

    def store(self, key: str, value: Any, metadata: Dict[str, Any] = None) -> None:
        """Store latest value, overwriting previous."""
        self._current_state[key] = value
        self._last_update[key] = datetime.utcnow()

    def retrieve(self, key: str) -> Optional[Any]:
        """Get current value if exists."""
        return self._current_state.get(key)

    def list_keys(self) -> List[str]:
        """List all tracked signals."""
        return list(self._current_state.keys())

    def get_all(self) -> Dict[str, Any]:
        """Snapshot of all current state."""
        return dict(self._current_state)


class ShortTermMemory(MemoryTier):
    """
    Sliding window history layer.

    Characteristics:
      • Keeps last N observations
      • Useful for trend detection, pattern matching
      • Fixed capacity with FIFO eviction

    Example:
      >>> stm = ShortTermMemory(window_size=10)
      >>> for i in range(15):
      ...     stm.store("price", 100 + i)
      >>> len(stm.retrieve("price"))  # Only 10 latest
      10
    """

    def __init__(self, window_size: int = 100):
        self.window_size = window_size
        self._windows: Dict[str, List[Any]] = {}

    def store(self, key: str, value: Any, metadata: Dict[str, Any] = None) -> None:
        """Add value to sliding window."""
        if key not in self._windows:
            self._windows[key] = []
        self._windows[key].append(value)
        if len(self._windows[key]) > self.window_size:
            self._windows[key].pop(0)

    def retrieve(self, key: str) -> Optional[List[Any]]:
        """Get all values in window."""
        return self._windows.get(key)

    def list_keys(self) -> List[str]:
        """List all tracked keys."""
        return list(self._windows.keys())

    def get_latest(self, key: str) -> Optional[Any]:
        """Get most recent value."""
        window = self._windows.get(key)
        return window[-1] if window else None


class LongTermMemory(MemoryTier):
    """
    Persistent knowledge base layer.

    Characteristics:
      • Unbounded storage (persisted to disk)
      • Historical patterns, learned rules
      • Indexed for fast retrieval

    Example:
      >>> ltm = LongTermMemory(storage=JSONStorage("kb.json"))
      >>> ltm.store("pattern_divergence", {"type": "macd", "accuracy": 0.75})
      >>> pattern = ltm.retrieve("pattern_divergence")
    """

    def __init__(self, storage=None):
        self.storage = storage  # Pluggable storage backend
        self._index: Dict[str, List[str]] = {}  # Key -> value_ids
        self._cache: Dict[str, Any] = {}  # In-memory fallback when storage=None

    def store(self, key: str, value: Any, metadata: Dict[str, Any] = None) -> None:
        """Persist value to long-term storage."""
        if self.storage:
            self.storage.write(key, value)
        else:
            self._cache[key] = value
        if key not in self._index:
            self._index[key] = []

    def retrieve(self, key: str) -> Optional[Any]:
        """Load value from long-term storage."""
        if self.storage:
            return self.storage.read(key)
        return self._cache.get(key)

    def list_keys(self) -> List[str]:
        """List all stored keys."""
        return list(self._index.keys())

    def query(self, pattern: str) -> List[Any]:
        """Search by pattern (requires storage support)."""
        if self.storage:
            return self.storage.search(pattern)
        return []


# ── E7: Infinite Memory — 4-tier architecture ─────────────────────────────

class ArchivalMemory(MemoryTier):
    """
    E7 — L4 Archival tier.

    Write-once, unbounded, rarely accessed historical records.
    Tracks access count per key for promotion/eviction decisions.

    Tier hierarchy:
      L1=Working(Sensory) → L2=Episodic(ShortTerm) → L3=Semantic(LongTerm) → L4=Archival
    """

    def __init__(self):
        self._archive: Dict[str, Any] = {}
        self._access_count: Dict[str, int] = {}
        self._stored_at: Dict[str, datetime] = {}

    def store(self, key: str, value: Any, metadata: Dict[str, Any] = None) -> None:
        """Archive value; does not overwrite existing entry."""
        if key not in self._archive:
            self._archive[key] = value
            self._access_count[key] = 0
            self._stored_at[key] = datetime.utcnow()

    def retrieve(self, key: str) -> Optional[Any]:
        """Read archived value and increment access count."""
        if key in self._archive:
            self._access_count[key] += 1
            return self._archive[key]
        return None

    def list_keys(self) -> List[str]:
        return list(self._archive.keys())

    def access_stats(self) -> Dict[str, int]:
        """Return access count per key (used by MemoryStack for promotion)."""
        return dict(self._access_count)


class MemoryStack:
    """
    E7: Infinite Memory Stack — 4-tier promotion and eviction manager.

    Tiers (Engram naming):
      L1 = Working   → SensoryMemory   (capacity=1 per key, fastest)
      L2 = Episodic  → ShortTermMemory (sliding window, FIFO eviction)
      L3 = Semantic  → LongTermMemory  (conceptual knowledge, persistent)
      L4 = Archival  → ArchivalMemory  (write-once historical records)

    Promotion rule: L4 key with access_count >= promote_threshold → copy to L3.
    Eviction rule:  L2 window overflow auto-evicts via FIFO (built into ShortTermMemory).
    """

    PROMOTE_THRESHOLD: int = 3  # accesses in L4 before promoting to L3

    def __init__(self, window_size: int = 100, storage=None):
        self.working = SensoryMemory()       # L1
        self.episodic = ShortTermMemory(window_size)  # L2
        self.semantic = LongTermMemory(storage)       # L3
        self.archival = ArchivalMemory()              # L4

    def store(self, key: str, value: Any, tier: int = 1) -> None:
        """
        Store value in the specified tier (1-4).

        tier=1 → Working (latest signal)
        tier=2 → Episodic (recent episode)
        tier=3 → Semantic (learned pattern)
        tier=4 → Archival (historical record)
        """
        if tier == 1:
            self.working.store(key, value)
        elif tier == 2:
            self.episodic.store(key, value)
        elif tier == 3:
            self.semantic.store(key, value)
        else:
            self.archival.store(key, value)

    def retrieve(self, key: str) -> Tuple[Optional[Any], int]:
        """
        Retrieve value searching L1→L4, return (value, tier_found).
        Returns (None, -1) if not found in any tier.
        """
        v = self.working.retrieve(key)
        if v is not None:
            return v, 1
        v = self.episodic.retrieve(key)
        if v is not None:
            return v, 2
        v = self.semantic.retrieve(key)
        if v is not None:
            return v, 3
        v = self.archival.retrieve(key)
        if v is not None:
            return v, 4
        return None, -1

    def promote_hot_archival(self) -> List[str]:
        """
        Promotion rule: move frequently-accessed L4 keys to L3 (semantic).

        Returns list of promoted keys.
        """
        promoted = []
        for key, count in self.archival.access_stats().items():
            if count >= self.PROMOTE_THRESHOLD:
                value, _ = self.retrieve(key)
                if value is not None:
                    self.semantic.store(key, value)
                    promoted.append(key)
        return promoted
